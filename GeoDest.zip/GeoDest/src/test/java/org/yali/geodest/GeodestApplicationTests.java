package org.yali.geodest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeodestApplicationTests {

	@Test
	void contextLoads() {
	}

}
