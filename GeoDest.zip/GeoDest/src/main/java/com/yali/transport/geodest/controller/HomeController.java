package com.yali.transport.geodest.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.yali.transport.geodest.common.CommonConstants;

@Controller
public class HomeController {

	@RequestMapping(value = { "/" })
	public String index() {
		return CommonConstants.HOME;
	}
	
	@RequestMapping(value = { "/home" })
	public ModelAndView home(@RequestParam(required = false) String message,
							 @RequestParam(required = false) String alertColor) {
		ModelAndView modelView = new ModelAndView();
		modelView.addObject("message", message);
		modelView.addObject("alertColor", alertColor);
		modelView.setViewName(CommonConstants.HOME);
		return modelView;
	}

	@RequestMapping(value = "/admin")
	public String admin() {
		return "admin";
	}
	
	@RequestMapping(value = "/contactUs")
	public String contactUs() {
		return "contactUs";
	}
	
	@RequestMapping(value="/aboutUs")
	public String aboutUs() {
		return "aboutUs";
	}
	
	@RequestMapping(value="/services")
	public String services() {
		return "services";
	}
	
	@RequestMapping(value="/tariffs")
	public String tariffs() {
		return "tariffs";
	}
	

}
