package com.yali.transport.geodest.service;

import java.util.List;

import com.yali.transport.geodest.model.DataUtilityModel;
import com.yali.transport.geodest.model.UserDetails;

public interface AdminService {

	public boolean checkValidUser(UserDetails userDetails);
	
	public List<DataUtilityModel> getAllDataUtility();
}
