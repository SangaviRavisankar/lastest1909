package com.yali.transport.geodest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.yali.transport.geodest.common.CommonConstants;
import com.yali.transport.geodest.model.Customer;
import com.yali.transport.geodest.model.DataUtilityModel;
import com.yali.transport.geodest.model.UserDetails;
import com.yali.transport.geodest.service.AdminService;
import com.yali.transport.geodest.service.CustomerService;

@Controller
@RequestMapping(value="/admin")
public class AdminController {

	@Autowired
	CustomerService customerService;
	
	@Autowired
	AdminService adminService;
	
	@RequestMapping(value = "/getAllBooking", method=RequestMethod.POST)
	public ModelAndView getAllBooking() {
		
		ModelAndView modelView = new ModelAndView();
		List<Customer> allbookingList = customerService.getAllBooking();
		modelView.addObject("allbookingList", allbookingList);
		modelView.setViewName(CommonConstants.ADMIN);
		return modelView;
	}

	@RequestMapping(value="/login", method=RequestMethod.POST)
	public ModelAndView loginProcess(UserDetails userDetails) {
		ModelAndView modelView = new ModelAndView();
		boolean vaildUser = adminService.checkValidUser(userDetails);
		if(vaildUser) {
			modelView.addObject("loginMsg", "Login Success");
			modelView.setViewName(CommonConstants.ADMIN);
		} else {
			modelView.addObject("loginMsg", "Login Failed");
			modelView.setViewName(CommonConstants.ADMIN);
		}
		return modelView;
	}
	
	@RequestMapping(value = "/getAllDataUtility", method = RequestMethod.POST)
	public @ResponseBody List<DataUtilityModel> getAllDataUtility() {
		List<DataUtilityModel> dataUtility = adminService.getAllDataUtility();
		return dataUtility;
	}
	
}
