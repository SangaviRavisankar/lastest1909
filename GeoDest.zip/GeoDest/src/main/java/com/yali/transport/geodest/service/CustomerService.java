package com.yali.transport.geodest.service;

import java.util.List;

import com.yali.transport.geodest.model.Customer;

public interface CustomerService {
	
	public boolean bookCab(Customer customer);
	
	public List<Customer> getAllBooking();
}
