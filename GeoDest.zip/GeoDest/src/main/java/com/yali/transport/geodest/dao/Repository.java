package com.yali.transport.geodest.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

public class Repository {

	@Autowired
	JdbcTemplate jdbcTemplate;  
}
