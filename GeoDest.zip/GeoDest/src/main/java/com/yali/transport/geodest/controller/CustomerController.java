package com.yali.transport.geodest.controller;

import java.io.IOException;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.yali.transport.geodest.model.Customer;
import com.yali.transport.geodest.service.CustomerService;
import com.yali.transport.geodest.utility.EmailUtility;

@Controller
@RequestMapping(value="/customer")
public class CustomerController {

	private static final Logger log = LoggerFactory.getLogger(CustomerController.class);
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	EmailUtility emailUtility;
	
	@RequestMapping(value = "/bookCab", method=RequestMethod.POST)
	public String bookCab(Customer customer) {
		boolean result = customerService.bookCab(customer);
		String message = "Booking is UnSuccessfull";
		String alertColor = "red";
		if(result) {
			message = "Booking is Success";
			alertColor = "green";
			try {
				emailUtility.sendmail(customer);
				log.info("EMail Sent");
			} catch (AddressException e) {
				e.printStackTrace();
			} catch (MessagingException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return "redirect:/home?message="+message+"&alertColor="+alertColor;
	}

}
