package com.yali.transport.geodest.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yali.transport.geodest.model.UserDetails;

public interface AdminRepository extends  JpaRepository<UserDetails, String>{

	List<UserDetails> findByName(String name);
}

