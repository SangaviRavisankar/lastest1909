package com.yali.transport.geodest.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="data_utility")
@SequenceGenerator(name="data_utility_seq", initialValue=1, allocationSize=1)
public class DataUtilityModel {

	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "data_utility_seq")
	@Column(name = "id")
	private int id;
	
	@Column(name = "data_name")
	private String dataName;
	
	@Column(name = "data_description")
	private String dataDescription;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDataName() {
		return dataName;
	}

	public void setDataName(String dataName) {
		this.dataName = dataName;
	}

	public String getDataDescription() {
		return dataDescription;
	}

	public void setDataDescription(String dataDescription) {
		this.dataDescription = dataDescription;
	}

}
