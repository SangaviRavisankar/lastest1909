package com.yali.transport.geodest.utility;

import org.springframework.stereotype.Repository;

@Repository
public class CommonDBUpdte {
	
}