package com.yali.transport.geodest.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "customer")
@SequenceGenerator(name="customer_seq", initialValue=1, allocationSize=1)
public class Customer {

	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "customer_seq")
	@Column(name = "id")
	private int id;

	@Column(name = "name")
	private String name;

	@Column(name = "from_location")
	private String fromLocation;

	@Column(name = "to_location")
	private String toLocation;

	@Column(name = "mobile")
	private String mobile;

	@Column(name = "date")
	private String date;

	@Column(name = "cab_type")
	private String cabType;

	@Column(name = "optional_msg")
	private String optionalMsg;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFromLocation() {
		return fromLocation;
	}

	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}

	public String getToLocation() {
		return toLocation;
	}

	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getCabType() {
		return cabType;
	}

	public void setCabType(String cabType) {
		this.cabType = cabType;
	}

	public String getOptionalMsg() {
		return optionalMsg;
	}

	public void setOptionalMsg(String optionalMsg) {
		this.optionalMsg = optionalMsg;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", fromLocation=" + fromLocation + ", toLocation=" + toLocation
				+ ", mobile=" + mobile + ", date=" + date + ", cabType=" + cabType + ", optionalMsg=" + optionalMsg
				+ "]";
	}

}
