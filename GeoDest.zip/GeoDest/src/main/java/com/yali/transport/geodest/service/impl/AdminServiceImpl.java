package com.yali.transport.geodest.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yali.transport.geodest.dao.AdminRepository;
import com.yali.transport.geodest.dao.DataUtilityRepository;
import com.yali.transport.geodest.model.DataUtilityModel;
import com.yali.transport.geodest.model.UserDetails;
import com.yali.transport.geodest.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {
	
	@Autowired
	AdminRepository adminRepository;
	
	@Autowired
	DataUtilityRepository dataUtilityRepository;
	
	public static final Logger log = LoggerFactory.getLogger(AdminServiceImpl.class);

	@Override
	public boolean checkValidUser(UserDetails userDetails) {
		List<UserDetails> userDetailsDB = adminRepository.findByName(userDetails.getName());
		for (UserDetails userDetailsServer : userDetailsDB) {
		    if(userDetailsServer.getPassword().equals(userDetails.getPassword())) {
		    	log.info("Valid User");
		    	return true;
		    }
		}
		log.info("Invalid User");
		return false;
	}
	
	@Override
	public List<DataUtilityModel> getAllDataUtility() {
		List<DataUtilityModel> dataUtility = dataUtilityRepository.findAll();
		return dataUtility;
	}

}
