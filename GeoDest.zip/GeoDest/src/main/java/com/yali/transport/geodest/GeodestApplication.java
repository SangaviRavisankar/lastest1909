package com.yali.transport.geodest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages={"com.yali"})
public class GeodestApplication {

	public static void main(String[] args) {
		SpringApplication.run(GeodestApplication.class, args);
	}

}
