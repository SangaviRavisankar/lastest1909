package com.yali.transport.geodest.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yali.transport.geodest.model.DataUtilityModel;

public interface DataUtilityRepository extends  JpaRepository<DataUtilityModel, String> {

}
