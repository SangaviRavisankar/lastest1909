package com.yali.transport.geodest.common;

public class CommonConstants {

	public static final String HOME = "home";
	public static final String ADMIN = "admin";
	public static final String CUSTOMER = "customer";
	public static final String MESSAGE = "message";
	public static final String SUCCESS = "Success";
	public static final String FAILURE = "Failure";
}
