package com.yali.transport.geodest.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yali.transport.geodest.dao.CustomerRepository;
import com.yali.transport.geodest.model.Customer;
import com.yali.transport.geodest.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {

	private static final Logger log = LoggerFactory.getLogger(CustomerServiceImpl.class);
	
	@Autowired
	CustomerRepository customerRepository;
	
	@Override
	public boolean bookCab(Customer customer) {
		try {
			customerRepository.save(customer);
			return true;
		}catch(Exception e) {
			log.info("Error updating the record");
		}
		return false;
	}

	@Override
	public List<Customer> getAllBooking() {
		return customerRepository.findAll();
	}

}
