package com.yali.transport.geodest.utility;

import java.io.IOException;
import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.yali.transport.geodest.model.Customer;

@Component
@Configuration
@PropertySource("classpath:application.properties")
public class EmailUtility {
	
	@Value( "${email.fromAddress}" )
	private String fromAddress;
	
	@Value( "${email.toAddress}" )
	private String toAddress;
	
	@Value( "${email.senderPassCode}" )
	private String senderPasscode;

	public void sendCustomerDetails(Customer customer) {

		String from = fromAddress;
		String to = toAddress;
		Properties emailProperties = new Properties();
		emailProperties.put("mail.smtp.auth", "true");
		emailProperties.put("mail.smtp.starttls.enable", "true");
		emailProperties.put("mail.smtp.host", "smtp.gmail.com");
		emailProperties.put("mail.smtp.port", 587);

		Session session = Session.getDefaultInstance(emailProperties,
				new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(fromAddress, senderPasscode);
					}
				});
		try {

			MimeMessage msg = new MimeMessage(session);
			msg.setFrom(new InternetAddress(fromAddress));
			msg.addRecipient(Message.RecipientType.TO, new InternetAddress(toAddress));
			msg.setSubject("New Cab Booking");
			msg.setText(generateEmailMsg(customer));
			Transport.send(msg);

		} catch (MessagingException mex) {
			mex.printStackTrace();
		}
	}
	
	public void sendmail(Customer customer) throws AddressException, MessagingException, IOException {
		   Properties props = new Properties();
		   props.put("mail.smtp.auth", "true");
		   props.put("mail.smtp.starttls.enable", "true");
		   props.put("mail.smtp.host", "smtp.gmail.com");
		   props.put("mail.smtp.port", "587");
		   
		   Session session = Session.getInstance(props, new javax.mail.Authenticator() {
		      protected PasswordAuthentication getPasswordAuthentication() {
		         return new PasswordAuthentication(fromAddress, senderPasscode);
		      }
		   });
		   Message msg = new MimeMessage(session);
		   msg.setFrom(new InternetAddress(fromAddress, false));

		   msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toAddress));
		   msg.setSubject("New Cab Booking");
		   msg.setContent(generateEmailMsg(customer), "text/html");
		   msg.setSentDate(new Date());

		   MimeBodyPart messageBodyPart = new MimeBodyPart();
		   messageBodyPart.setContent(generateEmailMsg(customer), "text/html");

//		   Multipart multipart = new MimeMultipart();
//		   multipart.addBodyPart(messageBodyPart);
//		   MimeBodyPart attachPart = new MimeBodyPart();
//
//		   attachPart.attachFile("/var/tmp/image19.png");
//		   multipart.addBodyPart(attachPart);
//		   msg.setContent(multipart);
		   Transport.send(msg);   
		}
	
	public String generateEmailMsg(Customer customer){
		String email = "<table border='1'>\r\n" + 
				"	<thead>\r\n" + 
				"		<tr>\r\n" + 
				"			<td>Customer Name</td>\r\n" + 
				"			<td>From Location</td>\r\n" + 
				"			<td>To Location</td>\r\n" + 
				"			<td>Mobile Number</td>\r\n" + 
				"			<td>Message</td>\r\n" + 
				"		</tr>\r\n" + 
				"	</thead>\r\n" + 
				"	<tbody>\r\n" + 
				"		<tr>\r\n" + 
				"			<td>"+customer.getName()+"</td>\r\n" + 
				"			<td>"+customer.getFromLocation()+"</td>\r\n" + 
				"			<td>"+customer.getToLocation()+"</td>\r\n" + 
				"			<td>"+customer.getMobile()+"</td>\r\n" + 
				"			<td>"+customer.getOptionalMsg()+"</td>\r\n" + 
				"		</tr>\r\n" + 
				"	</tbody>\r\n" + 
				"</table>";
		return email;
	}
}
